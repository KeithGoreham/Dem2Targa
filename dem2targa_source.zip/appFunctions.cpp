#include "StdAfx.h"
#include "appfunctions.h"

void ShowHelpInfo(void)
{
	using namespace std;

	string helpString;

	helpString  = "\n";
	helpString += " Help Information for dem2targa:\n\n";
	helpString += " Purpose:\n\n";
	helpString += "   This program converts a USGS .DEM Elevation file into a standard\n";
	helpString += "   Targa Image Map for use with imaging and 3D graphics applications.\n\n";
	helpString += " Usage:\n\n";
	helpString += "   dem2targa source.dem source.hdr output.tga [/g | /rgb | /rgba] [/v]\n\n";
	helpString += "     source.dem     Specifies the source DEM data file.\n";
	helpString += "     source.hdr     Specifies the source DEM header file.\n";
	helpString += "     output.tga     Specifies the name of the output TGA file.\n";
	helpString += "     /g             (default) Specifies an 8-bit grayscale height map.\n";
	helpString += "     /m             Specifies an 8-bit black OR white sea level mask.\n\n";
	helpString += "   The sea level mask can be used to mask off lakes and oceans in imaging\n   apps such as Photoshop.\n";

	cout << helpString;
}

void ShowSyntaxError(void)
{
	using namespace std;

	string helpString;

	helpString  = "\n";
	helpString += " The syntax of the command is incorrect. Type 'dem2targa /?' for help.\n";

	cout << helpString;

}