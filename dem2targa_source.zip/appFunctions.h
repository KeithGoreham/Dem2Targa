#pragma once

void ShowHelpInfo(void);		// Function to display help information text.
void ShowSyntaxError(void);		// Function to display syntax error message.