//////////////////////////////////////////////////////////////
// USGS .DEM to .TGA Converter
// �2007 by Keith Goreham
//////////////////////////////////////////////////////////////

// Include Files
#include "stdafx.h"
#include "appFunctions.h"

// Preprocessor Constants:
#define MAPTYPE_GRAYSCALEHEIGHT  1
#define MAPTYPE_GRAYSCALESEAMASK 2

int main(int argc, char* argv[])
{
	using namespace std;

	// Declare an array of strings to hold our command line arguments for easy comparisons.
	int		numArgs = argc - 1;
	string* args    = new string[numArgs];

	// Declare variables to hold our parsed command line data.
	unsigned int exportMapType    = 1;
	bool		 verboseOptionSet = false;
	string		 tgaOutputFilename;
	string		 demDataFilename;
	string		 demHeaderFilename;

	// Grab the command line arguments and put them into the array of strings.
	for (int i = 0; i < numArgs; i++){args[i] = argv[i + 1];}

	//----------------------------------------------------------------------
	// Command Line Parsing - Errors
	//----------------------------------------------------------------------

	// If there are no arguments at all, return a syntax error.
	if (argc < 2){ShowSyntaxError(); return 0;}

	// Check for a help request.
	for (i = 0; i < numArgs; i++)
	{
		if (args[i] == "/?"){ShowHelpInfo(); return 0;}
	}

	// Now check for too few arguments:
	if (numArgs < 3){ShowSyntaxError(); return 0;}

	// Now check for a '/' option in the first 3 arguments.
	for (i = 0; i < numArgs; i++)
	{
		if ((i <= 2) && (args[i][0] == '/'))
		{
			ShowSyntaxError();
			return 0;
		}
	}

	//----------------------------------------------------------------------
	// Command Line Parsing - Processing Options
	//----------------------------------------------------------------------
	
	for (i = 0; i < numArgs; i++)
	{
		if (i < 3)
		{
			switch (i)
			{
			case 0: demDataFilename   = args[i];
			case 1: demHeaderFilename = args[i];
			case 2: tgaOutputFilename = args[i];
			}
		}
		else
		{
			if		(args[i] == "/g")	{exportMapType    = MAPTYPE_GRAYSCALEHEIGHT;}
			else if (args[i] == "/m")   {exportMapType    = MAPTYPE_GRAYSCALESEAMASK;}
			else
			{
				cout << "\n Unknown option specified: " << args[i] << "\n"; 
				return 0;
			}
		}
	}

	//----------------------------------------------------------------------
	// File Operations - Attempt to open input and output files.
	//----------------------------------------------------------------------

	// Declare our filestream objects.
	ifstream demHeaderFile;
	ifstream demDataFile;
	ofstream tgaOutputFile;

	// Open the filestream objects using the supplied filenames and check to make sure they work.
	demHeaderFile.open(demHeaderFilename.c_str());
	if (!demHeaderFile.is_open()){cout << " ERROR! - Could not open DEM header file.\n";   return 0;}

	demDataFile.open  (demDataFilename.c_str(),   ios::binary);
	if (!demDataFile.is_open())  {cout << " ERROR! - Could not open DEM data file.\n";     return 0;}

	tgaOutputFile.open(tgaOutputFilename.c_str(), ios::binary);
	if (!tgaOutputFile.is_open()){cout << " ERROR! - Could not create TGA output file.\n"; return 0;}

	// We were just testing to see if the TGA file could be created. So we'll delete it and 
	// make it again later once we've processed everything (And gotten past the parts that 
	// could still go wrong.).
	tgaOutputFile.close();
	char buffer[256];
	sprintf(buffer, "del %s", tgaOutputFilename.c_str());
	system(buffer);
	
	//----------------------------------------------------------------------
	// Echo Back Option Selections to the User
	//----------------------------------------------------------------------

	switch (exportMapType)
	{
	case MAPTYPE_GRAYSCALEHEIGHT:  {cout << "\n Processing Grayscale Height Map...\n"; break;}
	case MAPTYPE_GRAYSCALESEAMASK: {cout << "\n Processing Grayscale Sea Mask...\n";   break;}
	}
	
	//----------------------------------------------------------------------
	// Parse the DEM header file. All we really need is the x and y 
	// dimensions of the DEM.
	//----------------------------------------------------------------------
	
	int	   numLinesRead = 0;
	string fileLine;
	char*  token1;
	char*  token2;

	unsigned int numDemRows = 0;
	unsigned int numDemCols = 0;

	while (demHeaderFile)
	{
		// Get a line of ASCI Data from the header file.
		getline(demHeaderFile, fileLine);
		
		// Declare a C-Style string to feed to strtok. And copy the string over.
		char* fileLineCStr = new char[fileLine.length()];
		
		// Copy the string over.
		sprintf(fileLineCStr, "%s", fileLine.c_str());

		// Grab the first and second tokens on this line.
		token1 = strtok(fileLineCStr, " ");
		token2 = strtok(NULL, " ");

		// And convert those tokens back to C++ strings.
		if (token1 != NULL)
		{
			string varType = token1;
			string value   = token2;

			if	(varType == "BYTEORDER")		// Format check
			{
				if (value != "M"){cout << " ERROR! - Byte Order Mismatch - Conversion Halted.\n"; return 0;}
			}
			else if (varType == "NROWS")
			{
				// Convert the string to an unsigned int using istringstream.
				std::istringstream iss;
				iss.str(token2);

				// Save the data.
				iss >> numDemRows;
			}
			else if (varType == "NCOLS")			
			{
				// Convert the string to an unsigned int using istringstream.
				std::istringstream iss;
				iss.str(token2);

				// Save the data.
				iss >> numDemCols;
			}
			else if (varType == "NBANDS")		// Format Check
			{
				if (value != "1"){cout << " ERROR! - Color Band Mismatch - Conversion Halted.\n"; return 0;}
			}
			else if (varType == "NBITS")		// Format Check
			{
				if (value != "16"){cout << " ERROR! - Bit Depth Mismatch - Conversion Halted.\n"; return 0;}
			}
		}
	}

	//----------------------------------------------------------------------
	// File Operations - Read in the DEM Data
	//----------------------------------------------------------------------

	unsigned int demPixelCount   = numDemRows * numDemCols;
	unsigned int demPixelMemSize = demPixelCount * 2;

	// Allocate memory for the DEM's data.
	unsigned short* demData = new unsigned short[demPixelCount];

	// Read in the data from the DEM.
	demDataFile.read((char*) demData, demPixelMemSize);

	// Swap the bytes to correct endianess issue.
	for (unsigned int j = 0; j < demPixelCount; j++)
	{
		demData[j] = (((demData[j] >> 8)) | (demData[j] << 8));
	}

	//----------------------------------------------------------------------
	// Process the Data based on the export type.
	//----------------------------------------------------------------------
	switch (exportMapType)
	{
	case MAPTYPE_GRAYSCALEHEIGHT: 
		{
			// Allocate memory for the .TGA pixel data.
			unsigned char* tgaData = new unsigned char[demPixelCount];

			// Resample the 16-bit DEM data down to 8 bits.
			for (unsigned int j = 0; j < demPixelCount; j++)
			{
				float fPixel;
				
				if (demData[j] > 10000){demData[j] = 0;}

				fPixel = (float)demData[j] / 8848.0f;		// Divide number in file by the height of Mt. Everest.
				fPixel = (fPixel * 255.0f) + 0.5f;			// Then multiply by 255.0 and round up to calculate our byte.
				
				tgaData[j] = (unsigned int)fPixel;			// Store the result as an integer byte.
			}

			// Open the .TGA file for writing.
			tgaOutputFile.open(tgaOutputFilename.c_str(), ios::binary);
			if (!tgaOutputFile.is_open()){cout << " ERROR! - Could not create TGA output file.\n"; return 0;}

			unsigned char  tgaIDLength		       = 0;					// Number of bytes contained in the image ID field.
			unsigned char  tgaColorMapType	       = 0;					// Color Map Type (zero for grayscale or true color).
			unsigned char  tgaImageType		       = 3;					// Image Type (3 for black and white images)
			unsigned char  tgaColorMapSpec[5];							// Color Map Specification (not using one)
			unsigned short tgaImageSpec_XOrigin    = 0;					// X location of lower-left corner.
			unsigned short tgaImageSpec_YOrigin    = 0;					// Y location of lower-left corner.
			unsigned short tgaImageSpec_Width      = numDemCols;		// Width of image in pixels
			unsigned short tgaImageSpec_Height     = numDemRows;		// Height of image in pixels
			unsigned char  tgaImageSpec_Depth	   = 8;					// Pixel Depth (8 for grayscale)
			unsigned char  tgaImageSpec_Descriptor = 0x20;
			unsigned char  tgaImageID		       = 0;

			// Zero out the memory used for the color map spec since we won't be using one.
			ZeroMemory(tgaColorMapSpec, 5);

			// Write the .TGA header.
			tgaOutputFile.write((char*) &tgaIDLength,			  1);	// ID Length
			tgaOutputFile.write((char*) &tgaColorMapType,		  1);	// Color Map Type
			tgaOutputFile.write((char*) &tgaImageType,			  1);	// Image Type
			tgaOutputFile.write((char*) tgaColorMapSpec,		  5);	// Color Map Specification
			tgaOutputFile.write((char*) &tgaImageSpec_XOrigin,    2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_YOrigin,    2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Width,      2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Height,     2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Depth,      1);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Descriptor, 1);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageID,			  1);	// Image ID

			// Write the image data.
			tgaOutputFile.write((char*) tgaData, demPixelCount);

			// Close the file.
			tgaOutputFile.close();

			// Delete the memory allocated for the data.
			if (tgaData != NULL){delete[] tgaData;};

			break;
		}
	case MAPTYPE_GRAYSCALESEAMASK:
		{
			// Allocate memory for the .TGA pixel data.
			unsigned char* tgaData = new unsigned char[demPixelCount];

			// Resample the 16-bit DEM data down to 8 bits.
			for (unsigned int j = 0; j < demPixelCount; j++)
			{
				if (demData[j] > 10000){tgaData[j] = 255;}
				else				   {tgaData[j] = 0;}
			}

			// Open the .TGA file for writing.
			tgaOutputFile.open(tgaOutputFilename.c_str(), ios::binary);
			if (!tgaOutputFile.is_open()){cout << " ERROR! - Could not create TGA output file.\n"; return 0;}

			unsigned char  tgaIDLength		       = 0;					// Number of bytes contained in the image ID field.
			unsigned char  tgaColorMapType	       = 0;					// Color Map Type (zero for grayscale or true color).
			unsigned char  tgaImageType		       = 3;					// Image Type (3 for black and white images)
			unsigned char  tgaColorMapSpec[5];							// Color Map Specification (not using one)
			unsigned short tgaImageSpec_XOrigin    = 0;					// X location of lower-left corner.
			unsigned short tgaImageSpec_YOrigin    = 0;					// Y location of lower-left corner.
			unsigned short tgaImageSpec_Width      = numDemCols;		// Width of image in pixels
			unsigned short tgaImageSpec_Height     = numDemRows;		// Height of image in pixels
			unsigned char  tgaImageSpec_Depth	   = 8;					// Pixel Depth (8 for grayscale)
			unsigned char  tgaImageSpec_Descriptor = 0x20;
			unsigned char  tgaImageID		       = 0;

			// Zero out the memory used for the color map spec since we won't be using one.
			ZeroMemory(tgaColorMapSpec, 5);

			// Write the .TGA header.
			tgaOutputFile.write((char*) &tgaIDLength,			  1);	// ID Length
			tgaOutputFile.write((char*) &tgaColorMapType,		  1);	// Color Map Type
			tgaOutputFile.write((char*) &tgaImageType,			  1);	// Image Type
			tgaOutputFile.write((char*) tgaColorMapSpec,		  5);	// Color Map Specification
			tgaOutputFile.write((char*) &tgaImageSpec_XOrigin,    2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_YOrigin,    2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Width,      2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Height,     2);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Depth,      1);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageSpec_Descriptor, 1);	// Image Specification
			tgaOutputFile.write((char*) &tgaImageID,			  1);	// Image ID

			// Write the image data.
			tgaOutputFile.write((char*) tgaData, demPixelCount);

			// Close the file.
			tgaOutputFile.close();

			// Delete the memory allocated for the data.
			if (tgaData != NULL){delete[] tgaData;};

			break;
		}
	}

	// We need to close the open files.
	demHeaderFile.close();
	demDataFile.close();
	tgaOutputFile.close();

	// And finally we clean up any memory that we've allocated:
	if (args != NULL)   {delete[] args;}
	if (demData != NULL){delete[] demData;}

	return 0;
}

