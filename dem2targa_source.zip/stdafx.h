// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

// Standard C/C++ Libraries:
#include <sstream>
#include <iostream>
#include <tchar.h>
#include <cstdlib>
#include <string>
#include <cmath>
#include <cstdio>
#include <fstream>

#include "windows.h"



// TODO: reference additional headers your program requires here
